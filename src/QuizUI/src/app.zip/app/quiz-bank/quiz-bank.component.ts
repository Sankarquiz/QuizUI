import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quiz-bank',
  templateUrl: './quiz-bank.component.html',
  styleUrls: ['./quiz-bank.component.css']
})
export class QuizBankComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
