import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-publish-quiz',
  templateUrl: './publish-quiz.component.html',
  styleUrls: ['./publish-quiz.component.css']
})
export class PublishQuizComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
