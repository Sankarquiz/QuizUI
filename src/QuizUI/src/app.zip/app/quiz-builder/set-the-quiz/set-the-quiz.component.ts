import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-set-the-quiz',
  templateUrl: './set-the-quiz.component.html',
  styleUrls: ['./set-the-quiz.component.css']
})
export class SetTheQuizComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
