import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-previous-quiz',
  templateUrl: './view-previous-quiz.component.html',
  styleUrls: ['./view-previous-quiz.component.css']
})
export class ViewPreviousQuizComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
